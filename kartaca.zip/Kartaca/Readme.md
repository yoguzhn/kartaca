1- venv kur.  https://flask.palletsprojects.com/en/1.1.x/installation/#installation
2 - pip install flask-restful
3- hello apisi yaz.
4- pip freeze > requirements.txt
5- Dockerfile yaz.
6- docker-compose doldur
7- docker-compose -d --build komutunu çalıştır (her değişiklik yaptığımda tekrardan build etmem lazım)
8- curl localhost:.....


